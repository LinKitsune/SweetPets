export interface Product {
    price: number,
    name: string,
    image: string,
    soldUnits: number,
    id: string
}