export const environment = {
  production: true,

  firebaseConfig : {
    apiKey: "AIzaSyDR3Pc869LOvsrYM9qNKKnt428gx_abVHs",
    authDomain: "registrapp-lk.firebaseapp.com",
    databaseURL: "https://registrapp-lk-default-rtdb.firebaseio.com",
    projectId: "registrapp-lk",
    storageBucket: "registrapp-lk.appspot.com",
    messagingSenderId: "270271363783",
    appId: "1:270271363783:web:8199e1308b48eacf91dce2",
    measurementId: "G-JXWDKHWNQ5"
  }
};
