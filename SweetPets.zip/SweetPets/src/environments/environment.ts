// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
    firebaseConfig : {
    apiKey: "AIzaSyDR3Pc869LOvsrYM9qNKKnt428gx_abVHs",
    authDomain: "registrapp-lk.firebaseapp.com",
    databaseURL: "https://registrapp-lk-default-rtdb.firebaseio.com",
    projectId: "registrapp-lk",
    storageBucket: "registrapp-lk.appspot.com",
    messagingSenderId: "270271363783",
    appId: "1:270271363783:web:8199e1308b48eacf91dce2",
    measurementId: "G-JXWDKHWNQ5"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
